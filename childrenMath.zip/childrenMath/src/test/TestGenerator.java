package test;

import controller.CommandParse;
import controller.Expression;
import controller.FractionNum;
import org.junit.Test;
public class TestGenerator {
    @Test
    public void basic() {
        String[] args={"-e","Exercises.txt","-a","Answers.txt"};
        CommandParse.main(args);
    }

}
