package controller;

public class Restrict {
        public static int _r=150;
}
