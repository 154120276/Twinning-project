package controller;



import java.util.List;

public class Expression {
//    static final int add = 1;
//    static final int sub = 2;
//    static final int mul = 3;
//    static final int div = 4;
    public FractionNum value;
    public Operation operation = null;
    public boolean bracket=false;
    public Expression(FractionNum v){
        value=v;
    }
    public Operation.type split(boolean end){
        Operation.type op = RandomUnit.getOperation();
//        System.out.println(op);
        switch (op){
            case div:
                if(this.value.isSmallerHalfRestrict()&&!this.value.isZero()){
                    operation = new OperationDiv( value);
                    op= Operation.type.div;
                    if(!end) {
                        switch (RandomUnit.getSide()) {
                            case Left:
                                switch (operation.left.split(true)){
                                    case add:
                                    case sub:
                                        operation.left.bracket=true;
                                        break;
                                }
                                break;
                            case Right:
                                switch (operation.right.split(true)){
                                    case add:
                                    case sub:
                                        operation.right.bracket=true;
                                        break;
                                    case div:
                                    case mul:
                                        operation.right.bracket=true;
                                        break;
                                }
                        }
                    }
                    break;
                }
            case mul:
                if(!this.value.isFraction()&&!this.value.isOne()&&!this.value.isZero()){
                    List<Integer> factors=this.value.findFactors();
                    if(factors.size()!=1) {
                        operation = new OperationMul( value,factors);
                        op= Operation.type.mul;
                        if(!end) {
                            switch (RandomUnit.getSide()) {
                                case Left:
                                    switch (operation.left.split(true)){
                                        case add:
                                        case sub:
                                            operation.left.bracket=true;
                                            break;
                                    }
                                    break;
                                case Right:
                                    switch (operation.right.split(true)){
                                        case add:
                                        case sub:
                                            operation.right.bracket=true;
                                            break;
                                    }
                            }
                        }
                        break;
                    }
                }
            case add:
                if(this.value.canConvertAdd()) {
                    operation = new OperationAdd( value);
                    op= Operation.type.add;
                    if(!end) {
                        switch (RandomUnit.getSide()) {
                            case Left:
                                operation.left.split(true);
                                break;
                            case Right:
                                operation.right.split(true);
                                break;
                        }
                    }
                    break;
                }
            case sub:
                if(!this.value.isRestrict()) {
                    operation = new OperationSub(value);
                    op= Operation.type.sub;
                    if(!end) {
                        switch (RandomUnit.getSide()) {
                            case Left:
                                switch (operation.left.split(true)) {
                                }
                                break;
                            case Right:
                                switch (operation.right.split(true)) {
                                    case add:
                                    case sub:
                                        operation.right.bracket=true;
                                }
                                break;
                        }
                    }
                    break;
                }
        }
        return op;
    }
    @Override
    public String toString(){
        if(operation!=null){
            if(bracket) {
                return "("+operation.toString()+")";
            }
            return operation.toString();
        }
        return value.toString();
    }
    public String toKatex(){
        if(operation!=null){
            if(bracket) {
                return "("+operation.toKatex()+")";
            }
            return operation.toKatex();
        }
        return value.toKatex();
    }
}
