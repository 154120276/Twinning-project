package controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class Result {
    static int expressionCnt=0;
    static int expressionMax=0;
    static StringBuilder Exercises= new StringBuilder();
    static StringBuilder Answers= new StringBuilder();
    private static final String ExercisesPath="Exercises.txt";
    private static final String AnswersPath="Answers.txt";
    public static void Write() {
        try {
            File file = new File(ExercisesPath);  //地址
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(Exercises.toString());
            osw.flush();
            osw.close();
        }catch (Exception e){}
        try {
            File file = new File(AnswersPath);  //地址
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(Answers.toString());
            osw.flush();
            osw.close();
        }catch (Exception e){}
    }
    public static void CalculateFile(String exercisesPath,String answersPath){
        int lineCount=1;
        int correctCount=0;
        int wrongCount=0;
        StringBuilder correct = new StringBuilder();
        StringBuilder wrong = new StringBuilder();
        FileLineReader exercises=new FileLineReader(exercisesPath);
        FileLineReader answers=new FileLineReader(answersPath);
        for(;;lineCount+=1){
            String e=exercises.read();
            if(e!=null){
                String[] lineSplit=e.split("\\.");
                   if(lineSplit.length==2){
                      e=lineSplit[1];
                   }
            }
            String a=answers.read();
            if(a!=null){
                String[] lineSplit=a.split("\\.");
                if(lineSplit.length==2){
                    a=lineSplit[1];
                }
            }
            if(e==null||a==null)
                break;

            System.out.println(e+"==="+a);
            if(Calculator.calculator.caculate(e).equal(Calculator.calculator.caculate(a))){
                correct.append(lineCount+",");
                correctCount+=1;
            }else {
                wrong.append(lineCount+",");
                wrongCount+=1;
            }
        }
        try {

            String cs=correct.toString();
            cs=cs.substring(0,cs.length()-1);
            String ws=wrong.toString();
            ws=ws.substring(0,ws.length()-1);
            File file = new File("Grade.txt");
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(
                    "Correct: "+correctCount+" ("+cs+")"
                            +"\n"+
                            "Wrong: "+wrongCount+" ("+ws+")"
            );
            osw.flush();
            osw.close();
        }catch (Exception e){}

    }
}
