package controller;

public class Operation {
    public String toKatex() {
        return "";
    }
    static enum type{
        add,sub,mul,div;
    }
    public Expression left;
    public Expression right;;
}
