package controller;

import java.util.Random;

public class RandomUnit {
    static int restrict=
//            Integer.MAX_VALUE
            50
            ;
    public static Random random=new Random();
    public static int getInt(){
        return Math.abs(random.nextInt());
    }
    public static int getRestrictInt(){
        return Math.abs(random.nextInt())%restrict;
    }
    public static boolean getBoolean(){
        return random.nextBoolean();
    }
    public static enum Side{
        Left,Right
    }
    public static Side getSide(){
        switch (random.nextInt()%2){
            case 0:
                return Side.Left;
            case 1:
                return Side.Right;
            default:return Side.Left;
        }
    }
    public static Operation.type getOperation(){
        switch (random.nextInt()%4){
            case 0:
                return Operation.type.add;
            case 1:
                return Operation.type.sub;
            case 2:
                return Operation.type.mul;
            case 3:
                return Operation.type.div;
            default:return Operation.type.add;
        }
    }
}
