package controller;


import java.util.ArrayList;
import java.util.List;

public class FractionNum {
    boolean reduced=false;
    //分子
    int numerator;

    //分母
    int denominator;

    public FractionNum(int n, int d) {
        numerator = n;
        denominator = d;
        reduction();
    }
    public FractionNum(int n) {
        numerator = n;
        denominator = 1;
    }
    public void set(int n, int d) {
        numerator = n;
        denominator = d;
        reduction();
    }
    public void set(int n) {
        numerator = n;
        denominator = 1;
    }
    public int getNum(){
        if(denominator!=1){
            System.out.println(new Throwable().getStackTrace()[0].toString());
        }
        return numerator;
    }
    public FractionNum() {
    }
    /**
     * 约分处理
     */
    public void reduction(){
        int times=gcd(numerator,denominator);
        numerator/=times;
        denominator/=times;
        if(times>1) {
            this.reduced = true;
        }
    }
    public double getDouble(){
        return ((double)numerator)/denominator;
    }
    public boolean canConvertAdd(){
        if(numerator==1&&denominator*2>Restrict._r)
            return false;
        return true;
    }
    public boolean isFraction(){
        return !(numerator%denominator==0);
    }
    public boolean isOne(){
        return numerator==denominator;
    }
    public boolean isZero(){
        return numerator==0;
    }
    public boolean isRestrict(){
        return (numerator/denominator)>=Restrict._r;
    }
    public boolean isPrime(){
        int val=numerator/denominator;
        int impossible=(int)Math.sqrt(val);
        for (int i = 2; i <= impossible / 2; i++) {
            if (val % i == 0)
                return true;
        }
        return false;
    }
    public boolean isSmallerHalfRestrict() {
        return (!this.isFraction())&&(numerator/denominator)<=(Restrict._r/2);
    }
    public boolean isReduced(){
        return reduced;
    }
    public void splitFractionAdd(FractionNum left, FractionNum right){
        int i=1;
        for(;i*denominator<Restrict._r;i+=1){

        }
        i-=1;
        if(i>50){
            i/=2;
            i+=1;
        }
//        System.out.println(i*denominator);
        int leftNumerator=0;
        while (leftNumerator<=0||leftNumerator>=i*numerator){
            if(i*numerator==0)
                i=1;
            leftNumerator=RandomUnit.getInt()%(i*numerator);
        }
        int rightNumerator=i*numerator-leftNumerator;
        left.set(leftNumerator,i*denominator);
        right.set(rightNumerator,i*denominator);
    }
    public void splitAdd(FractionNum left, FractionNum right){
        if(numerator==0){
            left.set(0);
            right.set(0);
            return;
        }
        int val=numerator/denominator;
        int leftInt=0;
        //限制加法左边的数不为0也不刚好是上一个值
        while(leftInt<=0) {
            leftInt=RandomUnit.getInt() % val;
        }
        left.set(leftInt,1);
        right.set(val-leftInt,1);
    }
    public void splitFractionSub(FractionNum left, FractionNum right){
        int i=1;
        for(;i*denominator<Restrict._r;i+=1){

        }
        i-=1;
        if(i==0){
            i=1;
        }
//        System.out.println(i*denominator);
        //left=
        int newDenominator=i*denominator;
        int leftNumerator=0;
        while (leftNumerator<=0||leftNumerator>=newDenominator){
            leftNumerator=newDenominator-(RandomUnit.getInt()%newDenominator);
        }
        int rightNumerator=newDenominator-leftNumerator;
        if(leftNumerator<1||newDenominator<1||rightNumerator<1||leftNumerator<1){
            System.out.println();
        }

        left.set(leftNumerator,newDenominator);
        right.set(rightNumerator,newDenominator);
    }

    /**
     * 假设将a转化为b-c则b=a+c c=b-a
     * 先生成b
     * a<b<Restrict._r
     * @param left
     * @param right
     */
    public void splitSub(FractionNum left, FractionNum right){
        int val=numerator/denominator;
        int range=Restrict._r-val;
//        System.out.println("range:"+range);
        int leftInt=val+((RandomUnit.getInt())%range+1);
        left.set(leftInt);
        right.set(leftInt-val);
    }
    @Override
    public String toString() {
        if(isFraction()){
            return numerator+"/"+denominator;
        }
        else return ""+numerator/denominator;
    }

    public String toKatex(){
        if(isFraction()){
            return "\\\\frac"+"{"+numerator+"}"+"{"+denominator+"}";
        }
        return ""+getNum();
    }
    /**
     * 辗转相除法（欧几里得算法）求最大公因数
     * @param a 第一个数
     * @param b 第二个数
     * @return 最大公因数
     */
    private static int gcd(int a,int b) {
        return (b==0)?a:gcd(b,a%b);
    }
    public List<Integer> findFactors(){
        int input=this.getNum();
        int k=2;
        List<Integer> list=new ArrayList<>();
        while (true) {
            if (input % k == 0) {
                list.add(k);
                input /= k;
            } else
                k++;
            if (input == 1) break;
        }
        return list;
    }


    public void splitDiv(FractionNum left, FractionNum right) {
        int val=getNum();
        int i=1;
        for(;i*val<Restrict._r;i+=1){
        }
        i-=1;
        if(i>10){
            i=(int)Math.sqrt(i);
        }
        left.set(i*val);
        right.set(i);
    }


    public void splitMul(FractionNum left, FractionNum right) {
        int val=getNum();
        int i=1;
        for(;i*val<Restrict._r;i+=1){
        }
        i-=1;
        left.set(i*val);
        right.set(i);
    }
    public static FractionNum add(FractionNum a,FractionNum b){
        return new FractionNum(a.numerator*b.denominator+b.numerator*a.denominator,b.denominator*a.denominator);
    }
    public static FractionNum sub(FractionNum a,FractionNum b){
        return new FractionNum(a.numerator*b.denominator-b.numerator*a.denominator,b.denominator*a.denominator);
    }
    public static FractionNum mul(FractionNum a,FractionNum b){
        return new FractionNum(a.numerator*b.numerator,b.denominator*a.denominator);
    }
    public static FractionNum div(FractionNum a,FractionNum b){
        return new FractionNum(a.numerator*b.denominator,b.numerator*a.denominator);
    }
    public boolean equal(FractionNum compare){
        return numerator==compare.numerator&&denominator==compare.denominator;
    }
//    public void splitFractionDiv(FractionNum left, FractionNum right) {
//
//    }
    public void splitFractionMul(FractionNum left, FractionNum right) {

    }

}
